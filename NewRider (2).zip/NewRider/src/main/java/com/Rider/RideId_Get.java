package com.Rider;

public class RideId_Get {
	private String rideId = null;
	public RideId_Get() {}
	
	public String getRideId() {
		return rideId;
	}
	public void setRideId(String rideId) {
		this.rideId = rideId;
	}
	
	

}
